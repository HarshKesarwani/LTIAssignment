package com.lti.customerConsumer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.customerConsumer.service.ConsumerService;

@RestController
@RibbonClient(
		  name = "ping-a-server",
		  configuration = ConsumerService.class)
public class ConsumerController {
	
	@Autowired
	ConsumerService consumerservice;

	@GetMapping(value = "/getcustomer")
	public String getcustomer() {
		System.out.println("Going to call customer service to get data!");
		return consumerservice.getcustomer();
	}

}
