package com.lti.customerConsumer.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@Service
public class ConsumerService {
	
	@Autowired
	RestTemplate restTemplate;
	@HystrixCommand(fallbackMethod = "callStudentServiceAndGetData_Fallback")
	public String getcustomer(){
		String response = restTemplate
				.exchange("http://localhost:9001/getcustomer"
						,HttpMethod.GET
						,null
						,new ParameterizedTypeReference<String>() {
						}).getBody();
		System.out.println("Response Received as " + response + " -  ");
		return "NORMAL FLOW !!! :::  Customer Details " + response + " -  " ;
	}
	@SuppressWarnings("unused")
	private String callStudentServiceAndGetData_Fallback(String schoolname) {
		System.out.println("Customer Service is down!!! fallback route enabled...");
		return "CIRCUIT BREAKER ENABLED!!!No Response From Student Service at this moment. Service will be back shortly - " ;
	}


	
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
