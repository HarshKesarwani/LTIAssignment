package com.lti.customer_producer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.customer_producer.Model.Customer;
import com.lti.customer_producer.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerservice;
	
	@PostMapping("/addcustomer")
	public Customer addCustomer(@RequestBody Customer customer)  {
		return customerservice.addCustomer(customer);
	}
	@GetMapping("/getcustomerbyid/{id}")
	public Customer getCustomerById(@PathVariable long id){
		return customerservice.getCustomer(id);
	}
	@PutMapping("/updatecustomer")
	public Customer updateCustomer(@RequestBody Customer customer,@PathVariable long id ) {
		return customerservice.updateCustomer(customer, id);
	}
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	@GetMapping("/getcustomer")
	public List<Customer> getcustomer(){
		return customerservice.getcustomer();
	}

	@DeleteMapping("/deletecustomer")
	public void deletecustomer(@PathVariable long id){
		customerservice.delete(id);
	}
	



	public Customer getDataFallBack() {
		
		Customer cust = new Customer();
		cust.setName("fallback-customer-name");
		cust.setAge(1000);
		cust.setAddress("fallback-customer-address");
		cust.setTypeofAccount("fallback-Type od account");

		return cust;
		
	}
	
	
	
	
	
}
