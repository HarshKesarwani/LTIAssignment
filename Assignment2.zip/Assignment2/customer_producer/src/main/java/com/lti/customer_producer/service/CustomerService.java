package com.lti.customer_producer.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.lti.customer_producer.Model.Customer;
import com.lti.customer_producer.repository.customerRepository;

public class CustomerService {
	
	@Autowired
	customerRepository customerRepository;

	public Customer addCustomer(@RequestBody Customer customer) {
		return customerRepository.save(customer);
	}

	public Customer getCustomer(long id) {
		return customerRepository.getById(id);
	}

	public Customer updateCustomer(Customer customer,long id) {
	
		return customerRepository.save(customer);
	}

	public List<Customer> getcustomer() {
		return customerRepository.findAll();
	}
	
	public void delete(Long id)   
	{  
	customerRepository.deleteById(id);  
	}  
	}
	



